# backend/voiceagent/agent_bus.py
"""
Agent Bus: minimal router + pluggable agents.

- Add new agents by subclassing ToolAgent (or matching the Protocol).
- Each agent implements:
    can_handle(text: str) -> bool
    handle(text: str) -> dict  (returns a small JSON for the voice agent to speak)

- Side effects (UI updates) are pushed via WebSocket broadcast:
    payload = {"type": "navigate", "url": "/dashboard?mode=text&q=24060"}
  The top-level React app listens and navigates accordingly.

This file is intentionally framework-light so it’s easy to unit test.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, List, Dict, Any, Optional
import os
import re
import requests

# ---- Types -----------------------------------------------------------------

class ToolAgent(Protocol):
    name: str
    def can_handle(self, text: str) -> bool: ...
    def handle(self, text: str) -> Dict[str, Any]: ...

# ---- Utilities --------------------------------------------------------------

def _public_base_url() -> str:
    # Public origin that serves your Django API (ngrok/Cloud Run)
    base = os.environ.get("PUBLIC_BASE_URL", "").rstrip("/")
    if not base:
        # Fallback for dev; change if needed
        base = "http://127.0.0.1:8000"
    return base

def _broadcast(payload: Dict[str, Any]) -> None:
    """
    Send a WS event to all connected clients.
    Requires Channels to be set up (InMemory is fine for dev).
    Safe no-op if Channels isn't available.
    """
    try:
        from channels.layers import get_channel_layer  # type: ignore
        from asgiref.sync import async_to_sync  # type: ignore
    except Exception:
        # Channels not installed/initialized; skip broadcast in unit tests.
        return

    layer = get_channel_layer()
    if not layer:
        return
    async_to_sync(layer.group_send)(
        "agent_broadcast",
        {"type": "agent_event", "payload": payload},
    )

def _extract_zip_or_text(text: str) -> str:
    """
    Bootstrap slot extraction:
    - Prefer a 5-digit US ZIP if present
    - Else return the raw text (e.g., "Blacksburg, VA")
    Replace with a Gemini-powered extractor later without changing call sites.
    """
    m = re.search(r"\b(\d{5})\b", text)
    return m.group(1) if m else text.strip()

# ---- Agents ----------------------------------------------------------------

class PropertiesSearchAgent:
    """
    Handles utterances like:
      - "find apartments in 24060"
      - "show condos in Blacksburg, VA"
    Side effects:
      - Broadcasts a 'navigate' event so the UI loads results
    Voice response:
      - Returns a concise 'summary' for the voice agent to speak
    """
    name = "properties.search"

    def can_handle(self, text: str) -> bool:
        t = text.lower()
        # crude signal; improve later with intent classifier or Gemini
        keywords = ("apartment", "apartments", "condo", "house", "homes",
                    "listings", "properties", "zip")
        return any(k in t for k in keywords)

    def handle(self, text: str) -> Dict[str, Any]:
        q = _extract_zip_or_text(text)

        # Call your existing search API
        base = _public_base_url()
        try:
            r = requests.get(
                f"{base}/api/properties/search/",
                params={"mode": "text", "q": q},
                timeout=15,
            )
            data = r.json() if r.status_code == 200 else {"results": []}
        except Exception:
            data = {"results": []}

        items = data.get("results", [])
        count = len(items)

        # Update UI: navigate so Dashboard auto-runs (you already wired this)
        _broadcast({"type": "navigate", "url": f"/dashboard?mode=text&q={q}"})

        # What the voice agent will speak
        return {"summary": f"I found {count} places for {q}.", "count": count}


class NearbyAgent:
    """
    Placeholder agent for 'nearby' intent (e.g., "search this area", "what's around me").
    Implementation options:
      - Read current map bounds from a user-scoped store and call /api/properties/search/?mode=nearby
      - Or ask the user a brief follow-up question to clarify area
    For now, we only acknowledge and instruct the UI to stay put.
    """
    name = "places.nearby"

    def can_handle(self, text: str) -> bool:
        t = text.lower()
        return any(k in t for k in ("nearby", "around here", "close by", "this area"))

    def handle(self, text: str) -> Dict[str, Any]:
        # Minimal behavior: let the UI handle map-based search via an existing button
        # You can later broadcast a specific action or results payload.
        return {"summary": "Okay—use the current map view to search this area."}

# ---- Router ----------------------------------------------------------------

@dataclass
class Router:
    agents: List[ToolAgent]

    def route(self, text: str) -> Dict[str, Any]:
        t = (text or "").strip()
        if not t:
            return {"summary": "What location should I search? You can say a ZIP or a city."}
        for agent in self.agents:
            try:
                if agent.can_handle(t):
                    return agent.handle(t)
            except Exception as e:
                # Don't break routing pipeline on one agent's error
                return {"summary": f"Something went wrong handling your request."}
        # default fallback
        return {"summary": "I can help find apartments or places nearby. Try a ZIP like 24060."}

# Singleton-style accessor (easy to import without circulars)
_BUS: Optional[Router] = None

def get_bus() -> Router:
    global _BUS
    if _BUS is None:
        _BUS = Router(agents=[
            PropertiesSearchAgent(),
            NearbyAgent(),
        ])
    return _BUS
