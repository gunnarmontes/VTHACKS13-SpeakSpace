# voiceagent/views.py
from __future__ import annotations
import json
import logging
import os
from typing import Any, Dict

from django.http import JsonResponse, HttpRequest
from django.views.decorators.csrf import csrf_exempt

from mapapp.serializers import SearchQuerySerializer, PlaceSerializer
from mapapp import places
from mapapp.utils import bounds_to_center_radius

from .agentbus import get_bus

logger = logging.getLogger(__name__)

# Authorization: Bearer <ELEVENLABS_AGENT_BEARER>
def _auth_ok(request: HttpRequest) -> bool:
    auth = (request.headers.get("Authorization") or "").strip()
    token = (os.environ.get("ELEVENLABS_AGENT_BEARER") or "").strip()
    logger.debug("Auth header = %r, expected = %r", auth, f"Bearer {token}")
    return auth == f"Bearer {token}" or auth == token


# ----------------------------------------------------------------------
# Legacy endpoint: routes arbitrary utterances to the agent bus
# ----------------------------------------------------------------------
@csrf_exempt
def agent_route(request: HttpRequest):
    if request.method != "POST":
        return JsonResponse({"detail": "POST required"}, status=405)

    if not _auth_ok(request):
        logger.warning("Unauthorized webhook call to agent_route")
        return JsonResponse({"detail": "unauthorized"}, status=401)

    try:
        body: Dict[str, Any] = json.loads(request.body or "{}")
        utterance = (body.get("utterance") or "").strip()
        if not utterance:
            return JsonResponse(
                {"summary": "What location should I search? You can say a ZIP or a city."}
            )

        result = get_bus().route(utterance)
        if not isinstance(result, dict):
            result = {"summary": "Sorry, something went wrong handling your request."}

        logger.info("agent_route handled utterance=%r -> %s", utterance, result.get("summary"))
        return JsonResponse(result)

    except Exception as e:
        logger.exception("agent_route error: %s", e)
        return JsonResponse(
            {"summary": "I ran into a problem handling that request."}, status=500
        )


# ----------------------------------------------------------------------
# New endpoint: directly performs a property search
# ----------------------------------------------------------------------
@csrf_exempt
def make_query(request: HttpRequest):
    if request.method != "POST":
        return JsonResponse({"detail": "POST required"}, status=405)

    if not _auth_ok(request):
        logger.warning("Unauthorized webhook call to make_query")
        return JsonResponse({"detail": "unauthorized"}, status=401)

    try:
        body: Dict[str, Any] = json.loads(request.body or "{}")
        qp = SearchQuerySerializer(data=body)
        if not qp.is_valid():
            return JsonResponse({"results": [], "error": qp.errors}, status=400)
        params = qp.validated_data

        mode = (params.get("mode") or "").strip().lower()
        q    = (params.get("q") or "").strip()
        sw   = params.get("sw")
        ne   = params.get("ne")

        raw = []
        if mode == "text":
            search_text = q if q else "apartments"
            raw = places.text_search_apartments(text_query=search_text, page_size=15)
            if not raw and q:
                raw = places.text_search_apartments(
                    text_query=f"apartments near {q}", page_size=15
                )
        elif mode == "nearby":
            br = bounds_to_center_radius(sw, ne)
            if not br:
                return JsonResponse({"results": [], "error": "Invalid bounds."}, status=400)
            lat, lng, radius_m = br
            raw = places.nearby_search_apartments(
                {"lat": lat, "lng": lng}, radius_m=radius_m, page_size=15
            )
        else:
            return JsonResponse({"results": [], "error": "Unknown mode."}, status=400)

        # Normalize + filter
        normalized = [places.normalize_place(p) for p in raw]
        ALLOWED_TYPES = {"apartment_complex", "property_management_company", "real_estate_agency"}
        filtered = [
            r for r in normalized
            if (r.get("primaryType") in ALLOWED_TYPES)
            or any(t in ALLOWED_TYPES for t in (r.get("types") or []))
        ]

        serializer = PlaceSerializer(filtered, many=True)
        return JsonResponse({"results": serializer.data})

    except places.PlacesError as e:
        logger.exception("Places error: %s", e)
        return JsonResponse({"results": [], "error": str(e)}, status=502)
    except Exception as e:
        logger.exception("make_query error: %s", e)
        return JsonResponse(
            {"results": [], "error": "Something went wrong."}, status=500
        )
