# voiceagent/voiceagent/views.py
from __future__ import annotations
import json
import logging
import os
from typing import Any, Dict

from django.http import JsonResponse, HttpRequest
from django.views.decorators.csrf import csrf_exempt

from .agentbus import get_bus

logger = logging.getLogger(__name__)

# Authorization: Bearer <ELEVENLABS_AGENT_BEARER>
AGENT_BEARER = os.environ.get("ELEVENLABS_AGENT_BEARER", "change-me").strip()

def _auth_ok(request):
    auth = (request.headers.get("Authorization") or "").strip()
    # TEMP: log a safe preview so we see the format
    logger.warning("agent_route Authorization header (preview) = %r", (auth[:12] + "…") if auth else "<empty>")
    # Accept either "Bearer <token>" or raw "<token>" while debugging
    return auth == f"Bearer {AGENT_BEARER}" or auth == AGENT_BEARER


@csrf_exempt
def agent_route(request: HttpRequest):
    """
    POST /api/agent/route/
    Body: { "utterance": "<latest transcript or user request>" }
    Returns: { "summary": "...", "count": N }
    Side effects (UI updates) are broadcast by agents via Channels.
    """
    if request.method != "POST":
        return JsonResponse({"detail": "POST required"}, status=405)

    if AGENT_BEARER and not _auth_ok(request):
        logger.warning("Unauthorized webhook call to agent_route")
        return JsonResponse({"detail": "unauthorized"}, status=401)

    try:
        body: Dict[str, Any] = json.loads(request.body or "{}")
        utterance = (body.get("utterance") or "").strip()
        if not utterance:
            return JsonResponse({"summary": "What location should I search? You can say a ZIP or a city."})

        result = get_bus().route(utterance)
        if not isinstance(result, dict):
            result = {"summary": "Sorry, something went wrong handling your request."}

        logger.info("agent_route handled utterance=%r -> %s", utterance, result.get("summary"))
        return JsonResponse(result)

    except Exception as e:
        logger.exception("agent_route error: %s", e)
        return JsonResponse({"summary": "I ran into a problem handling that request."}, status=500)
